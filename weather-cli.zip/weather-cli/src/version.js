export function version(){
    const packagejason = require('../package.json');
    console.log(packagejason.version);
}