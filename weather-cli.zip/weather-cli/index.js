#!/usr/bin/env node
console.log('Welcom to PJ weather forecast');

require = require('esm')(module);
require('./src/cli').cli(process.argv);